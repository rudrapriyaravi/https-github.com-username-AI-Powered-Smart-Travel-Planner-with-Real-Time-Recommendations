import os
import json
import random
import hashlib
import requests
from datetime import datetime
from flask import (
    Flask, render_template, request, jsonify,
    redirect, url_for, flash, send_file, session
)
from flask_login import (
    LoginManager, UserMixin, login_user,
    logout_user, login_required, current_user
)
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import io

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "easytrip-secret-2024-change-me")

# ── Database ──────────────────────────────────────────
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///easytrip.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)

# ── Login Manager ─────────────────────────────────────
login_manager = LoginManager(app)
login_manager.login_view = "login"

# ── API Keys ──────────────────────────────────────────
GEMINI_API_KEY       = os.environ.get("GEMINI_API_KEY", "AIzaSyClwxfN73fP8L8rKD2w-htpmloPTB2SZ_M")
OPENWEATHER_API_KEY  = os.environ.get("OPENWEATHER_API_KEY", "76fa32411321e95318cb4444800bf334")   # free at openweathermap.org
EXCHANGE_API_KEY     = os.environ.get("EXCHANGE_API_KEY", "5b85dce840ddce936d741bf2 ")       # free at exchangerate-api.com

GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent"

image_cache = {}

# ── Budget tiers (USD / day) ──────────────────────────
BUDGET_TIERS = {
    "low":    {"flight": "200–450",  "hotel": "20–50",   "meals": "15–30",  "transport": "5–15",  "activities": "10–25",  "label": "Budget"},
    "medium": {"flight": "400–800",  "hotel": "80–150",  "meals": "40–70",  "transport": "15–30", "activities": "30–60",  "label": "Mid-range"},
    "high":   {"flight": "700–1500", "hotel": "200–400", "meals": "80–150", "transport": "30–60", "activities": "60–120", "label": "Premium"},
    "luxury": {"flight": "1500+",    "hotel": "400+",    "meals": "150+",   "transport": "60+",   "activities": "120+",   "label": "Luxury"},
}

# ─────────────────────────────────────────────────────
# MODELS
# ─────────────────────────────────────────────────────
class User(UserMixin, db.Model):
    id           = db.Column(db.Integer, primary_key=True)
    email        = db.Column(db.String(120), unique=True, nullable=False)
    username     = db.Column(db.String(80),  unique=True, nullable=False)
    password     = db.Column(db.String(200), nullable=False)
    created_at   = db.Column(db.DateTime, default=datetime.utcnow)
    trips        = db.relationship("SavedTrip", backref="user", lazy=True)

class SavedTrip(db.Model):
    id              = db.Column(db.Integer, primary_key=True)
    user_id         = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    destination     = db.Column(db.String(200))
    days            = db.Column(db.Integer)
    budget          = db.Column(db.String(20))
    travel_style    = db.Column(db.String(30))
    group_type      = db.Column(db.String(30))
    interests       = db.Column(db.Text)         # JSON list
    start_date      = db.Column(db.String(20))
    accommodation   = db.Column(db.String(30))
    itinerary_json  = db.Column(db.Text)         # full enriched itinerary JSON
    extras_json     = db.Column(db.Text)         # tips, warnings, budget, packing
    created_at      = db.Column(db.DateTime, default=datetime.utcnow)

@login_manager.user_loader
def load_user(uid):
    return User.query.get(int(uid))

# ─────────────────────────────────────────────────────
# GEMINI HELPER
# ─────────────────────────────────────────────────────
def ask_gemini(prompt, json_mode=False):
    if GEMINI_API_KEY in ("YOUR_GEMINI_API_KEY_HERE", "AIzaSyClwxfN73fP8L8rKD2w-htpmloPTB2SZ_M"):
        return None
    headers = {"Content-Type": "application/json"}
    body = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {"temperature": 0.7, "maxOutputTokens": 2048},
    }
    try:
        res = requests.post(f"{GEMINI_URL}?key={GEMINI_API_KEY}", headers=headers, json=body, timeout=25)
        data = res.json()
        text = data["candidates"][0]["content"]["parts"][0]["text"]
        if json_mode:
            text = text.strip()
            if text.startswith("```"):
                text = text.split("```")[1]
                if text.startswith("json"):
                    text = text[4:]
            return json.loads(text.strip())
        return text.strip()
    except Exception as e:
        print("Gemini error:", e)
        return None

# ─────────────────────────────────────────────────────
# GENERATE FULL ITINERARY
# ─────────────────────────────────────────────────────
def ai_generate_itinerary(destination, days, interests, budget, travel_style, group_type, places):
    place_names = [p["name"] for p in places] if places else []
    place_hint  = f"Use these real places where possible: {', '.join(place_names[:15])}." if place_names else ""
    interests_str = ", ".join(interests) if interests else "general sightseeing"

    prompt = f"""You are an expert travel planner. Create a detailed {days}-day itinerary for {destination}.

Traveller profile:
- Group: {group_type}
- Budget: {budget}
- Travel style: {travel_style}
- Interests: {interests_str}

{place_hint}

Return ONLY a valid JSON object, no markdown, no extra text:
{{
  "itinerary": [
    {{
      "day": 1,
      "theme": "Short catchy theme",
      "morning":   {{"place":"Exact place name","activity":"Vivid 2-sentence description","tip":"One practical tip"}},
      "afternoon": {{"place":"Exact place name","activity":"Vivid 2-sentence description","tip":"One practical tip"}},
      "evening":   {{"place":"Exact place name","activity":"Vivid 2-sentence description","tip":"One practical tip"}},
      "restaurant":{{"name":"Restaurant name","cuisine":"Cuisine type","price_range":"$ or $$ or $$$","why":"One sentence"}}
    }}
  ],
  "destination_tips": ["tip1","tip2","tip3","tip4"],
  "warnings": ["warning1","warning2"],
  "budget_breakdown": {{
    "accommodation_per_night":"USD range",
    "meals_per_day":"USD range",
    "transport_per_day":"USD range",
    "activities_per_day":"USD range",
    "total_estimate":"Total for whole trip USD"
  }},
  "packing_list": {{
    "essentials":["item1","item2","item3","item4","item5"],
    "clothing":["item1","item2","item3","item4"],
    "tech":["item1","item2","item3"],
    "health":["item1","item2","item3"]
  }}
}}

Generate exactly {days} days. Make descriptions vivid and genuinely useful."""
    return ask_gemini(prompt, json_mode=True)

# ─────────────────────────────────────────────────────
# REGENERATE A SINGLE SLOT
# ─────────────────────────────────────────────────────
def ai_regenerate_slot(destination, day_num, slot, interests, budget, travel_style, group_type):
    interests_str = ", ".join(interests) if interests else "general sightseeing"
    prompt = f"""You are an expert travel planner.
Regenerate ONLY the {slot} slot for Day {day_num} of a {destination} trip.

Traveller profile: {group_type}, {budget} budget, {travel_style} style, interests: {interests_str}.

Return ONLY a valid JSON object:
{{
  "place": "Exact place name different from before",
  "activity": "Vivid 2-sentence description of what to do and why it is special",
  "tip": "One practical insider tip"
}}"""
    return ask_gemini(prompt, json_mode=True)

# ─────────────────────────────────────────────────────
# PLACES (Wikipedia)
# ─────────────────────────────────────────────────────
def get_places(city):
    url    = "https://en.wikipedia.org/w/api.php"
    params = {
        "action": "query", "list": "search",
        "srsearch": f"{city} tourist attractions OR {city} famous places OR {city} landmarks",
        "format": "json", "srlimit": 15,
    }
    headers = {"User-Agent": "easytrip-ai-app/1.0"}
    try:
        response = requests.get(url, params=params, headers=headers, timeout=8)
        if response.status_code != 200:
            return []
        results = response.json().get("query", {}).get("search", [])
        places  = []
        for item in results:
            title = item.get("title", "")
            if any(bad in title.lower() for bad in [
                "list","tourism","district","state","country",
                "history","economy","geography","culture of","people of","religion","politics"
            ]):
                continue
            if len(title.split()) > 7:
                continue
            lat, lon = get_coordinates(title, city)
            if lat is None:
                continue
            places.append({"name": title, "lat": lat, "lon": lon})
            if len(places) >= 12:
                break
        if len(places) < 3:
            lat, lon = get_coordinates(city, city)
            if lat and lon:
                places.append({"name": city + " City Centre", "lat": lat, "lon": lon})
        return places
    except Exception as e:
        print("Error fetching places:", e)
        return []

# ─────────────────────────────────────────────────────
# COORDINATES (OpenStreetMap)
# ─────────────────────────────────────────────────────
# ─────────────────────────────────────────
# GET COORDINATES (OpenStreetMap)
# ─────────────────────────────────────────
def get_coordinates(place, city=""):
    query = f"{place}, {city}" if city and city.lower() not in place.lower() else place
    params = {"q": query, "format": "json", "limit": 1}
    headers = {"User-Agent": "easytrip-ai-app/1.0"}
 
    try:
        res = requests.get(
            "https://nominatim.openstreetmap.org/search",
            params=params, headers=headers, timeout=6
        )
        data = res.json()
        if data:
            return float(data[0]["lat"]), float(data[0]["lon"])
    except Exception as e:
        print("Coord error:", place, e)
 
    return None, None

# ─────────────────────────────────────────────────────
# IMAGES (Wikimedia)
# ─────────────────────────────────────────────────────
def get_place_image(place):
    if place in image_cache:
        return image_cache[place]
    try:
        params = {"action":"query","titles":place,"prop":"pageimages","pithumbsize":600,"format":"json"}
        res    = requests.get("https://en.wikipedia.org/w/api.php", params=params,
                              headers={"User-Agent":"easytrip-ai-app/1.0"}, timeout=5)
        pages  = res.json().get("query",{}).get("pages",{})
        for page in pages.values():
            thumb = page.get("thumbnail",{}).get("source")
            if thumb:
                image_cache[place] = thumb
                return thumb
    except Exception as e:
        print("Image error:", place, e)
    fallback = "https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=600&q=70"
    image_cache[place] = fallback
    return fallback

# ─────────────────────────────────────────────────────
# NEARBY RESTAURANTS (Overpass API / OpenStreetMap)
# ─────────────────────────────────────────────────────
def get_nearby_restaurants(lat, lon, limit=4):
    """Fetch real restaurants near a coordinate via Overpass API."""
    query = f"""
[out:json][timeout:10];
(
  node["amenity"="restaurant"](around:800,{lat},{lon});
  node["amenity"="cafe"](around:800,{lat},{lon});
);
out {limit * 3};
"""
    try:
        res  = requests.post("https://overpass-api.de/api/interpreter", data={"data": query}, timeout=12)
        data = res.json()
        seen, results = set(), []
        for el in data.get("elements", []):
            tags = el.get("tags", {})
            name = tags.get("name", "").strip()
            if not name or name in seen:
                continue
            seen.add(name)
            results.append({
                "name":    name,
                "cuisine": tags.get("cuisine", "local").replace(";", ", "),
                "lat":     el.get("lat"),
                "lon":     el.get("lon"),
            })
            if len(results) >= limit:
                break
        return results
    except Exception as e:
        print("Overpass error:", e)
        return []

# ─────────────────────────────────────────────────────
# WEATHER (OpenWeatherMap)
# ─────────────────────────────────────────────────────
def get_weather(destination, start_date=None):
    if not OPENWEATHER_API_KEY:
        return None
    try:
        lat, lon = get_coordinates(destination)
        if not lat:
            return None
        url    = "https://api.openweathermap.org/data/2.5/forecast"
        params = {"lat": lat, "lon": lon, "appid": OPENWEATHER_API_KEY, "units": "metric", "cnt": 7}
        res    = requests.get(url, params=params, timeout=6)
        data   = res.json()
        if data.get("cod") != "200":
            return None
        forecasts = []
        seen_dates = set()
        for item in data.get("list", []):
            date = item["dt_txt"].split(" ")[0]
            if date in seen_dates:
                continue
            seen_dates.add(date)
            forecasts.append({
                "date":        date,
                "temp_min":    round(item["main"]["temp_min"]),
                "temp_max":    round(item["main"]["temp_max"]),
                "description": item["weather"][0]["description"].title(),
                "icon":        item["weather"][0]["icon"],
            })
        return {"city": data.get("city",{}).get("name", destination), "forecasts": forecasts}
    except Exception as e:
        print("Weather error:", e)
        return None

# ─────────────────────────────────────────────────────
# CURRENCY CONVERSION
# ─────────────────────────────────────────────────────
def get_exchange_rates(base="USD"):
    """Fetch exchange rates, return dict or None."""
    if not EXCHANGE_API_KEY:
        # fallback: use open.er-api.com (no key needed for basic)
        try:
            res  = requests.get(f"https://open.er-api.com/v6/latest/{base}", timeout=6)
            data = res.json()
            if data.get("result") == "success":
                return data.get("rates", {})
        except:
            pass
        return None
    try:
        res  = requests.get(f"https://v6.exchangerate-api.com/v6/{EXCHANGE_API_KEY}/latest/{base}", timeout=6)
        data = res.json()
        return data.get("conversion_rates", {})
    except Exception as e:
        print("Exchange rate error:", e)
        return None

# Popular currencies for the converter widget
DISPLAY_CURRENCIES = ["USD", "EUR", "GBP", "INR", "JPY", "AUD", "CAD", "SGD", "AED", "THB"]

# ─────────────────────────────────────────────────────
# FALLBACK ITINERARY
# ─────────────────────────────────────────────────────
def fallback_itinerary(places, days, interests, budget, travel_style, group_type):
    if not places:
        places = [
            {"name": "City Centre",    "lat": 20.0,  "lon": 78.0},
            {"name": "Local Market",   "lat": 20.01, "lon": 78.01},
            {"name": "Scenic Viewpoint","lat": 20.02, "lon": 78.02},
        ]
    days   = max(1, min(days, 14))
    random.shuffle(places)
    used   = []

    def pick():
        for p in places:
            if p not in used:
                used.append(p); return p
        used.clear(); return places[0]

    primary    = interests[0] if interests else "culture"
    budget_tag = {"low":" on a budget","medium":"","high":" with a premium touch","luxury":" in luxury style"}.get(budget,"")
    itinerary  = []
    for day in range(1, days + 1):
        m, a, e = pick(), pick(), pick()
        itinerary.append({
            "day": day, "theme": f"Exploring {m['name']}",
            "morning":   {"place": m["name"], "activity": f"Start your morning at {m['name']}{budget_tag}. Take your time to soak in the atmosphere.", "tip": "Arrive early to beat the crowds."},
            "afternoon": {"place": a["name"], "activity": f"Spend your afternoon at {a['name']}, a highlight for {primary} lovers{budget_tag}.", "tip": "Check opening hours before visiting."},
            "evening":   {"place": e["name"], "activity": f"Wind down your evening at {e['name']}{budget_tag}. A great spot to reflect on the day.", "tip": "Perfect for golden hour photos."},
            "restaurant": {"name": "Ask locals for their favourite", "cuisine": "Local", "price_range": "$$", "why": "The best food finds come from local recommendations."},
        })
    return itinerary

# ─────────────────────────────────────────────────────
# ENRICH ITINERARY (coords + images + nearby restaurants)
# ─────────────────────────────────────────────────────
def enrich_itinerary(raw_itinerary, places, destination):
    coords_lookup = {p["name"].lower(): (p["lat"], p["lon"]) for p in places}

    def get_coords_for(name):
        key = name.lower()
        if key in coords_lookup:
            return coords_lookup[key]
        for k, v in coords_lookup.items():
            if k in key or key in k:
                return v
        return get_coordinates(name, destination)

    enriched = []
    for day in raw_itinerary:
        enriched_day = {
            "day": day["day"], "theme": day.get("theme", f"Day {day['day']}"),
            "restaurant": day.get("restaurant", {}),
        }
        for slot in ["morning", "afternoon", "evening"]:
            sd         = day.get(slot, {})
            place_name = sd.get("place", destination)
            lat, lon   = get_coords_for(place_name)
            enriched_day[slot] = {
                "place":    place_name,
                "activity": sd.get("activity", ""),
                "tip":      sd.get("tip", ""),
                "image":    get_place_image(place_name),
                "lat":      lat if lat else 20.0,
                "lon":      lon if lon else 78.0,
            }
        # nearby restaurants for morning slot coordinates
        m = enriched_day["morning"]
        enriched_day["nearby_restaurants"] = get_nearby_restaurants(m["lat"], m["lon"])
        enriched.append(enriched_day)
    return enriched

# ─────────────────────────────────────────────────────
# PDF EXPORT  (client-side via print — no server libs)
# The route below returns an HTML page styled for print.
# ─────────────────────────────────────────────────────
@app.route("/export-pdf", methods=["POST"])
def export_pdf():
    """Return a print-ready HTML page the browser can save as PDF."""
    data = request.get_json()
    return render_template("pdf_export.html", **data)

# ─────────────────────────────────────────────────────
# AUTH ROUTES
# ─────────────────────────────────────────────────────
@app.route("/signup", methods=["GET", "POST"])
def signup():
    if current_user.is_authenticated:
        return redirect(url_for("home"))
    if request.method == "POST":
        email    = request.form.get("email","").strip().lower()
        username = request.form.get("username","").strip()
        pw       = request.form.get("password","")
        if not email or not username or not pw:
            flash("All fields are required.", "error")
        elif User.query.filter_by(email=email).first():
            flash("Email already registered.", "error")
        elif User.query.filter_by(username=username).first():
            flash("Username taken.", "error")
        else:
            user = User(email=email, username=username, password=generate_password_hash(pw))
            db.session.add(user); db.session.commit()
            login_user(user)
            flash("Account created! Welcome to EasyTrip.", "success")
            return redirect(url_for("dashboard"))
    return render_template("auth.html", mode="signup")

@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        email = request.form.get("email","").strip().lower()
        pw    = request.form.get("password","")
        user  = User.query.filter_by(email=email).first()
        if user and check_password_hash(user.password, pw):
            login_user(user, remember=True)
            return redirect(request.args.get("next") or url_for("dashboard"))
        flash("Invalid email or password.", "error")
    return render_template("auth.html", mode="login")

@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("home"))

@app.route("/dashboard")
@login_required
def dashboard():
    trips = SavedTrip.query.filter_by(user_id=current_user.id).order_by(SavedTrip.created_at.desc()).all()
    return render_template("dashboard.html", trips=trips)

@app.route("/trip/<int:trip_id>")
@login_required
def view_trip(trip_id):
    trip = SavedTrip.query.get_or_404(trip_id)
    if trip.user_id != current_user.id:
        flash("Access denied.", "error")
        return redirect(url_for("dashboard"))
    itinerary  = json.loads(trip.itinerary_json)
    extras     = json.loads(trip.extras_json) if trip.extras_json else {}
    interests  = json.loads(trip.interests) if trip.interests else []
    map_points = []
    for day in itinerary:
        for slot in ["morning", "afternoon", "evening"]:
            pt = day[slot]
            if pt.get("lat") and pt.get("lon"):
                map_points.append({"lat": pt["lat"], "lon": pt["lon"], "label": pt["place"]})
    return render_template(
        "plan.html",
        destination=trip.destination, days=trip.days, itinerary=itinerary,
        map_points=map_points, budget=trip.budget, travel_style=trip.travel_style,
        group_type=trip.group_type, interests=interests,
        start_date=trip.start_date, accommodation=trip.accommodation,
        ai_powered=True, ai_key_set=bool(GEMINI_API_KEY),
        destination_tips=extras.get("destination_tips", []),
        warnings=extras.get("warnings", []),
        budget_breakdown=extras.get("budget_breakdown", {}),
        packing_list=extras.get("packing_list", {}),
        weather=extras.get("weather"), exchange_rates=extras.get("exchange_rates"),
        saved_trip_id=trip_id,
    )

@app.route("/delete-trip/<int:trip_id>", methods=["POST"])
@login_required
def delete_trip(trip_id):
    trip = SavedTrip.query.get_or_404(trip_id)
    if trip.user_id == current_user.id:
        db.session.delete(trip); db.session.commit()
        flash("Trip deleted.", "success")
    return redirect(url_for("dashboard"))

# ─────────────────────────────────────────────────────
# API: REGENERATE ONE SLOT
# ─────────────────────────────────────────────────────
@app.route("/api/regenerate-slot", methods=["POST"])
def api_regenerate_slot():
    body        = request.get_json()
    destination = body.get("destination","")
    day_num     = body.get("day", 1)
    slot        = body.get("slot","morning")
    interests   = body.get("interests", [])
    budget      = body.get("budget","medium")
    travel_style= body.get("travel_style","balanced")
    group_type  = body.get("group_type","solo")

    result = ai_regenerate_slot(destination, day_num, slot, interests, budget, travel_style, group_type)
    if not result:
        return jsonify({"error": "AI unavailable"}), 503

    place = result.get("place", destination)
    result["image"] = get_place_image(place)
    lat, lon = get_coordinates(place, destination)
    result["lat"] = lat or 20.0
    result["lon"] = lon or 78.0
    return jsonify(result)

# ─────────────────────────────────────────────────────
# API: EXCHANGE RATES
# ─────────────────────────────────────────────────────
@app.route("/api/exchange-rates")
def api_exchange_rates():
    rates = get_exchange_rates("USD")
    if rates:
        filtered = {c: rates[c] for c in DISPLAY_CURRENCIES if c in rates}
        return jsonify({"rates": filtered, "base": "USD"})
    return jsonify({"error": "unavailable"}), 503

# ─────────────────────────────────────────────────────
# API: SAVE TRIP
# ─────────────────────────────────────────────────────
@app.route("/api/save-trip", methods=["POST"])
@login_required
def api_save_trip():
    body = request.get_json()
    trip = SavedTrip(
        user_id       = current_user.id,
        destination   = body.get("destination"),
        days          = body.get("days"),
        budget        = body.get("budget"),
        travel_style  = body.get("travel_style"),
        group_type    = body.get("group_type"),
        interests     = json.dumps(body.get("interests", [])),
        start_date    = body.get("start_date",""),
        accommodation = body.get("accommodation","hotel"),
        itinerary_json= json.dumps(body.get("itinerary", [])),
        extras_json   = json.dumps(body.get("extras", {})),
    )
    db.session.add(trip); db.session.commit()
    return jsonify({"id": trip.id, "message": "Trip saved!"})

# ─────────────────────────────────────────────────────
# MAIN ROUTES
# ─────────────────────────────────────────────────────
@app.route("/")
def home():
    return render_template("index.html")

@app.route("/plan", methods=["GET", "POST"])
def plan():
    ai_key_set = GEMINI_API_KEY not in ("YOUR_GEMINI_API_KEY_HERE", "")

    if request.method == "POST":
        destination   = request.form.get("destination","").strip()
        days_raw      = request.form.get("days","3")
        budget        = request.form.get("budget","medium")
        travel_style  = request.form.get("travel_style","balanced")
        group_type    = request.form.get("group_type","solo")
        interests     = request.form.getlist("interests")
        start_date    = request.form.get("start_date","")
        accommodation = request.form.get("accommodation","hotel")
        user_currency = request.form.get("user_currency","USD")

        try:
            days = max(1, min(int(days_raw), 14))
        except ValueError:
            days = 3

        if not destination:
            return render_template("plan.html", error="Please enter a destination.", ai_key_set=ai_key_set)

        places  = get_places(destination)
        ai_data = None
        if ai_key_set:
            ai_data = ai_generate_itinerary(destination, days, interests, budget, travel_style, group_type, places)

        if ai_data and "itinerary" in ai_data:
            raw              = ai_data["itinerary"][:days]
            itinerary        = enrich_itinerary(raw, places, destination)
            ai_powered       = True
            destination_tips = ai_data.get("destination_tips", [])
            warnings         = ai_data.get("warnings", [])
            budget_breakdown = ai_data.get("budget_breakdown", {})
            packing_list     = ai_data.get("packing_list", {})
        else:
            raw              = fallback_itinerary(places, days, interests, budget, travel_style, group_type)
            itinerary        = enrich_itinerary(raw, places, destination)
            ai_powered       = False
            destination_tips = []
            warnings         = []
            budget_breakdown = {}
            packing_list     = {}

        # Flight + hotel cost estimator
        tier_data    = BUDGET_TIERS.get(budget, BUDGET_TIERS["medium"])
        cost_estimate = {
            "tier":          tier_data["label"],
            "flight":        tier_data["flight"],
            "hotel_night":   tier_data["hotel"],
            "meals_day":     tier_data["meals"],
            "transport_day": tier_data["transport"],
            "activities_day":tier_data["activities"],
            "days":          days,
        }

        # Weather
        weather = get_weather(destination, start_date)

        # Exchange rates
        exchange_rates = get_exchange_rates("USD")
        if exchange_rates:
            exchange_rates = {c: exchange_rates[c] for c in DISPLAY_CURRENCIES if c in exchange_rates}

        map_points = []
        for day in itinerary:
            for slot in ["morning", "afternoon", "evening"]:
                pt = day[slot]
                if pt["lat"] and pt["lon"]:
                    map_points.append({"lat": pt["lat"], "lon": pt["lon"], "label": pt["place"]})

        return render_template(
            "plan.html",
            destination=destination, days=days, itinerary=itinerary,
            map_points=map_points, budget=budget, travel_style=travel_style,
            group_type=group_type, interests=interests, start_date=start_date,
            accommodation=accommodation, ai_powered=ai_powered, ai_key_set=ai_key_set,
            destination_tips=destination_tips, warnings=warnings,
            budget_breakdown=budget_breakdown, packing_list=packing_list,
            cost_estimate=cost_estimate, weather=weather,
            exchange_rates=exchange_rates, user_currency=user_currency,
            saved_trip_id=None,
        )

    return render_template("plan.html", ai_key_set=ai_key_set)

# ─────────────────────────────────────────────────────
# INIT & RUN
# ─────────────────────────────────────────────────────
with app.app_context():
    db.create_all()

if __name__ == "__main__":
    app.run(debug=True)